> [!NOTE]
> this repository is no longer maintained, as i don't use quizlet anymore. it was a nice run!

<br><br><hr><br><br>

## quizlethacks
a few quizlet hacks to make you "cooler" than you already are!!

pick a folder:
- [blast](https://github.com/VillainsRule/QuizletHacks/tree/master/blast)
- [blocks](https://github.com/VillainsRule/QuizletHacks/tree/master/blocks)
- [live](https://github.com/VillainsRule/QuizletHacks/tree/master/live)
- [match](https://github.com/VillainsRule/QuizletHacks/tree/master/match/normal)
- [match (multiplayer)](https://github.com/VillainsRule/QuizletHacks/tree/master/match/multiplayer)

then pick a hack and put it in the browser console!
